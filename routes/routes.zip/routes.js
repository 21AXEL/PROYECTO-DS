const express = require('express');
const router = express.Router();
const controlador = require('../controllers/controller');
const verificarToken = require('../middlewares/verificarToken');

// Proteger las rutas con el middleware
router.use(verificarToken); // <-- TODAS las rutas a partir de aquí requieren token
// Proyectos
router.get('/proyectos', controlador.obtenerProyectos);
router.post('/proyectos', controlador.crearProyecto);

/**
 * @swagger
 * /api/proyectos:
 *   get:
 *     summary: Obtener todos los proyectos
 *     tags:
 *       - Proyectos
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de proyectos
 */
router.get('/proyectos', verificarToken, controlador.obtenerProyectos);

/**
 * @swagger
 * /api/proyectos:
 *   post:
 *     summary: Crear un nuevo proyecto
 *     tags:
 *       - Proyectos
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nombreProyecto: { type: string }
 *               descripcion: { type: string }
 *               fechaInicio: { type: string }
 *               fechaFin: { type: string }
 *               costo: { type: number }
 *               estado: { type: string }
 *               tareas:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     nombreTarea: { type: string }
 *                     descripcion: { type: string }
 *                     completado: { type: boolean }
 *                     fechaEntrega: { type: string }
 *     responses:
 *       201:
 *         description: Proyecto creado exitosamente
 */
router.post('/proyectos', verificarToken, controlador.crearProyecto);

//... y rutas de tareas igual protegidas

router.post('/proyectos/:id/tareas', controlador.agregarTarea);
router.put('/proyectos/:id/tareas/:tareaId', controlador.actualizarTarea);
router.delete('/proyectos/:id/tareas/:tareaId', controlador.eliminarTarea);

/**
 * @swagger
 * /api/tareas/filtrar:
 *   get:
 *     summary: Filtrar tareas por estado o vencimiento
 *     tags:
 *       - Tareas
 *     parameters:
 *       - in: query
 *         name: estado
 *         schema: { type: string }
 *       - in: query
 *         name: vencidas
 *         schema: { type: boolean }
 *     responses:
 *       200:
 *         description: Lista de tareas filtradas
 */
// Filtro
router.get('/tareas/filtrar', controlador.filtrarTareas);

module.exports = router;
